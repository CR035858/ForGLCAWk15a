package com.greatlearning.libmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.greatlearning.libmgmt.controller","com.greatlearning.libmgmt.entity","com.greatlearning.libmgmt.repository","com.greatlearning.libmgmt.service"})
public class LibmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibmgmtApplication.class, args);
	}

}
